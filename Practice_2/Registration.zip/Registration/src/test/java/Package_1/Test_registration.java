package Package_1;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import javax.swing.*;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Test_registration {

    private static WebDriver driver;
    private static Random random = new Random();

    @BeforeClass
    public static void setup() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Lina\\IdeaProjects\\geckodriver.exe");
        driver = new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://lknew.qa2.cdek.ru");
        WebElement buttonReg = driver.findElement(By.xpath(".//*[@id='nav1']/li[1]/a"));
        buttonReg.click();
    }

    @Test
    public  void surnameReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement surname = driver.findElement(By.id("registerform-surname"));
        surname.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Фамилия».", "Необходимо заполнить «Фамилия».", error);
    }

    @Test
    public void surnameReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement surname = driver.findElement(By.id("registerform-surname"));
        surname.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "\"Фамилия\" содержит недопустимые символы.", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        surname.clear();
        surname.sendKeys("Хренова" + random.nextInt(100));
    }

    @Test
    public  void nameReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement name = driver.findElement(By.id("registerform-name"));
        name.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Имя».", "Необходимо заполнить «Имя».", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
    }

    @Test
    public void nameReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement name = driver.findElement(By.id("registerform-name"));
        name.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "\"Имя\" содержит недопустимые символы.", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        name.clear();
        name.sendKeys("Гадя");
    }

    @Test
    public  void patronymicReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement patronymic = driver.findElement(By.id("registerform-patronymic"));
        patronymic.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Отчество».", "Необходимо заполнить «Отчество».", error);
    }

    @Test
    public void patronymicReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement patronymic = driver.findElement(By.id("registerform-patronymic"));
        patronymic.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "\"Отчество\" содержит недопустимые символы.", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        patronymic.clear();
        patronymic.sendKeys("Петрович");
    }

    @Test
    public  void loginReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement login = driver.findElement(By.id("registerform-login"));
        login.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        Assert.assertEquals("Обязательно заполнить «Логин».", "Необходимо заполнить «Логин».", error);
    }

    @Test
    public void loginReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement login = driver.findElement(By.id("registerform-login"));
        login.sendKeys("ShishMish" + random.nextInt(100));
    }

    @Test
    public void passwordReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement password = driver.findElement(By.id("registerform-password"));
        password.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        Assert.assertEquals("Обязательно заполнить «Пароль».", "Необходимо заполнить «Пароль».", error);
    }

    @Test
    public void passwordReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement password = driver.findElement(By.id("registerform-password"));
        password.sendKeys("123456");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement passwordconfirm = driver.findElement(By.id("registerform-passwordconfirm"));
        passwordconfirm.clear();
        passwordconfirm.sendKeys("123456");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
    }

    @Test
    public  void passwordconfirmReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement passwordconfirm = driver.findElement(By.id("registerform-passwordconfirm"));
        passwordconfirm.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        Assert.assertEquals("Обязательно заполнить «Повторите пароль».", "Необходимо заполнить «Повторите пароль».", error);
    }

    @Test
    public void passwordconfirmReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement passwordconfirm = driver.findElement(By.id("registerform-passwordconfirm"));
        passwordconfirm.sendKeys("123456");
    }


    @Test
    public void cityReg() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement userCity = driver.findElement(By.id("select2-registerform-cityid-container"));
        userCity.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement userCityInner = driver.findElement(By.xpath("/html/body/span/span/span[1]/input"));
        userCityInner.sendKeys("Новосиб");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement selectCity = driver.findElement(By.cssSelector(".select2-results__option--highlighted"));
        selectCity.click();

        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement userStreet = driver.findElement(By.id("select2-registerform-streetid-container"));
        userStreet.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement userStreetInner = driver.findElement(By.xpath("/html/body/span/span/span[1]/input"));
        userStreetInner.sendKeys("Дарго");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement selectStreet = driver.findElement(By.cssSelector(".select2-results__option--highlighted"));
        selectStreet.click();
    }


    @Test
    public  void houseReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement house = driver.findElement(By.id("registerform-house"));
        house.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Дом».", "Необходимо заполнить «Дом».", error);
    }

    @Test
    public void houseReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement house = driver.findElement(By.id("registerform-house"));
        house.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "\"Дом\" содержит недопустимые символы.", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        house.clear();
        house.sendKeys("3");
    }

    @Test
    public  void flatReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement flat = driver.findElement(By.id("registerform-flat"));
        flat.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Квартира (Офис)».", "Необходимо заполнить «Квартира (Офис)».", error);
    }

    @Test
    public void flatReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement flat = driver.findElement(By.id("registerform-flat"));
        flat.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "\"Квартира (Офис)\" содержит недопустимые символы.", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        flat.clear();
        flat.sendKeys("203");
    }

    @Test
    public void phoneTypeReg() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        WebElement phoneType = driver.findElement(By.id("registerform-phonetype"));
        phoneType.click();
        WebElement mobileType = driver.findElement(By.xpath("//*[@id=\"registerform-phonetype\"]/option[2]"));
        mobileType.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        phoneType.click();
    }

    @Test
    public  void phoneReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement phone = driver.findElement(By.id("registerform-phone"));
        phone.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Телефон».", "Необходимо заполнить «Телефон».", error);
    }

    @Test
    public void phoneReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement phone = driver.findElement(By.id("registerform-phone"));
        phone.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "Телефон может содержать только цифры и " +
                "соответствовать одному из следующих шаблонов: (858) 555-1212 или 8585551212 или (213)555 1212", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        phone.clear();
        phone.sendKeys("9529312556");
    }

    @Test
    public  void emailReg1() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement email = driver.findElement(By.id("registerform-email"));
        email.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Обязательно заполнить «Email».", "Необходимо заполнить «Email».", error);
    }

    @Test
    public void emailReg2() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement email = driver.findElement(By.id("registerform-email"));
        email.sendKeys("123%^$%#*&");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement h1 = driver.findElement(By.cssSelector(".site-register>h1"));
        h1.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        String error = driver.findElement(By.cssSelector("div.has-error p.help-block")).getText();
        //JOptionPane.showMessageDialog(null, error);
        Assert.assertEquals("Введены недопустимые символы", "Значение «Email» не является правильным email адресом.", error);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        email.clear();
        email.sendKeys("ShishMish" + random.nextInt(100) + "@gmail.com");
    }



    @Test
    public void companyformReg() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        WebElement companyform = driver.findElement(By.id("registerform-companyform"));
        companyform.click();
        WebElement mobileType = driver.findElement(By.xpath("//*[@id=\"registerform-companyform\"]/option[7]"));
        mobileType.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        companyform.click();
    }

    @Test
    public void companyactivityReg() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        WebElement companyactivity = driver.findElement(By.id("registerform-companyactivity"));
        companyactivity.click();
        WebElement mobileType = driver.findElement(By.xpath("//*[@id=\"registerform-companyactivity\"]/option[7]"));
        mobileType.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        companyactivity.click();
    }

    @Test
    public void informationsourceReg() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        WebElement informationsource = driver.findElement(By.id("registerform-informationsource"));
        informationsource.click();
        WebElement mobileType = driver.findElement(By.xpath("//*[@id=\"registerform-informationsource\"]/option[4]"));
        mobileType.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("\"Oh, nooooo!\"");}
        informationsource.click();
    }


    @AfterClass
    public  static  void tearDown() {
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement regButton = driver.findElement(By.name("register-button"));
        regButton.submit();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}


        boolean hasError = false;
        WebElement login = driver.findElement(By.id("loginform-login"));
        login.sendKeys("ShishMish95");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement Passwd = driver.findElement(By.id("loginform-password"));
        Passwd.sendKeys("123456");
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement CheckRemMe = driver.findElement(By.id("loginform-rememberme"));
        if (CheckRemMe.isSelected()){
                hasError = true;
        }
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        Assert.assertTrue("Чекбокс включен!",hasError);
        CheckRemMe.click();
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        Assert.assertTrue("Чекбокс теперь выключен ;-)",hasError);
        try{Thread.sleep(500);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}
        WebElement LoginButton = driver.findElement(By.name("login-button"));
        LoginButton.click();
        try{Thread.sleep(2000);}
        catch (InterruptedException e){System.out.println("Oh, nooooo!");}

        driver.close();
    }
}
